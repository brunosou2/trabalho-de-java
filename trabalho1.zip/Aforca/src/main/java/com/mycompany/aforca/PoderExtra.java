/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;

/**
 *
 * @author bruno
 */

public interface PoderExtra {
    
    String cor = "";        
    int forcaExtra = 200;      
    
    
    void usarRaio();
}
