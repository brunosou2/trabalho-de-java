/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;

/**
 *
 * @author bruno
 */
class Aprendiz extends Forca {

    
    public Aprendiz(int vida, String nome) {
        super(40, vida, "Aprendiz", nome); 
    }

   
    public void atacar(Forca f) {
        System.out.println(nome + " (Aprendiz) está atacando com força " + this.forca);
    }

    
    public void setForca() {
        this.forca = 40;
        System.out.println(nome + " agora tem força " + this.forca);
    }
}

