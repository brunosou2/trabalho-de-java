/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;

/**
 *
 * @author bruno
 */

abstract class Forca {
    int forca;
    int vida;
    String genero;
    String nome;

   
    public Forca(int forca, int vida, String genero, String nome) {
        this.forca = forca;
        this.vida = vida;
        this.genero = genero;
        this.nome = nome;
    }


    public abstract void atacar(Forca f);
}


