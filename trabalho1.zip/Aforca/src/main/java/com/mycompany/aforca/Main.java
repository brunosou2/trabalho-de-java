/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aforca;

/**
 *
 * @author bruno
 */
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        
        Padawan Padawan = new Padawan(100, "");
        Cavaleiro Cavaleiro = new Cavaleiro(200, "");
        Lord Lord = new Lord(200, "");
        Aprendiz Aprendiz = new Aprendiz(200, "");

        
        MestreJedi MestreJedi = new MestreJedi(300, "");
        MestreSith MestreSith = new MestreSith(300, "");

        
        Padawan.atacar(Padawan);
        Cavaleiro.atacar(Cavaleiro);
        MestreJedi.atacar(MestreJedi);
        MestreSith.atacar(MestreSith);
        Lord.atacar(Lord);
        Aprendiz.atacar(Aprendiz);

        
        MestreJedi.usarRaio();
        MestreSith.usarRaio();
    }
}



