/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;

/**
 *
 * @author bruno
 */

class Cavaleiro extends Forca {

    
    public Cavaleiro(int vida, String nome) {
        super(70, vida, "Cavaleiro", nome); 
    }

    
    
    public void atacar(Forca f) {
        System.out.println(nome + " (Cavaleiro) está atacando com força " + this.forca);
    }

    
    public void setForca() {
        this.forca = 70; 
        System.out.println(nome + " agora tem força " + this.forca);
    }
}

