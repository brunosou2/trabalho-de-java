/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;

/**
 *
 * @author bruno
 */

class MestreJedi extends Forca implements PoderExtra {

   
    public MestreJedi(int vida, String nome) {
        super(100, vida, "Mestre Jedi", nome); 
    }

    
    
    public void atacar(Forca f) {
        System.out.println(nome + " (Mestre Jedi) está atacando com força " + this.forca);
    }

    
    public void usarRaio() {
        System.out.println(nome + " (Mestre Jedi) usou o Raio com poder extra de " + forcaExtra + " pontos!");
    }
}
