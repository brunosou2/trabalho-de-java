/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aforca;


/**
 *
 * @author bruno
 */
class MestreSith extends Forca implements PoderExtra {

    
    public MestreSith(int vida, String nome) {
        super(100, vida, "Mestre Sith", nome); // Define a força como 100 por padrão
    }

   
    public void atacar(Forca f) {
        System.out.println(nome + " (Mestre Sith) está atacando com força " + this.forca);
    }

    

    public void usarRaio() {
        System.out.println(nome + " (Mestre Sith) usou o Raio com poder extra de " + forcaExtra + " pontos!");
    }
}

