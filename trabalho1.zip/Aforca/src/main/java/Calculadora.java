/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bruno
 */
// Classe Calculadora
public class Calculadora {
    // Atributos
    private int num1;
    private int num2;

    // Construtor
    public Calculadora(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    // Métodos getters e setters
    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    // Método soma
    public int some() {
        return num1 + num2;
    }

    // Método subtração
    public int subtraia() {
        return num1 - num2;
    }

    // Método divisão (tratando divisão por zero)
    public int divida() {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            System.out.println("Erro: Divisão por zero!");
            return 0;
        }
    }

    // Método multiplicação
    public int multiplique() {
        return num1 * num2;
    }
}

