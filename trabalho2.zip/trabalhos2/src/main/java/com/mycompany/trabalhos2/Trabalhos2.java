/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trabalhos2;
import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author bruno
 */
public class Trabalhos2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String operador;
        int num1 = 0, num2 = 0;

        while (true) {
            // Solicitando o operador
            System.out.println("Digite o operador (+, -, /, *, ou '.' para sair): ");
            operador = scanner.next();

            if (operador.equals(".")) {
                break; // Sai do loop quando o operador é '.'
            }

            // Tratamento de exceção para garantir que números válidos sejam inseridos
            try {
                System.out.println("Digite o primeiro número: ");
                num1 = scanner.nextInt();

                System.out.println("Digite o segundo número: ");
                num2 = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, digite um número.");
                scanner.next(); // Limpar a entrada inválida
                continue; // Reinicia o loop
            }

            // Criação da calculadora
            Calculadora calc = new Calculadora(num1, num2);

            // Operações com base no operador
            switch (operador) {
                case "+":
                    System.out.println("A soma de " + num1 + " e " + num2 + " é: " + calc.some());
                    break;
                case "-":
                    System.out.println("A subtração de " + num1 + " por " + num2 + " é: " + calc.subtraia());
                    break;
                case "/":
                    try {
                        System.out.println("A divisão de " + num1 + " por " + num2 + " é: " + calc.divida());
                    } catch (ArithmeticException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case "*":
                    System.out.println("A multiplicação de " + num1 + " e " + num2 + " é: " + calc.multiplique());
                    break;
                default:
                    System.out.println("Operador inválido!");
            }
        }

        scanner.close(); // Fecha o scanner após o loop
    }
}

