/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bruno
 */
package com.mycompany.trabalhos2;

/**
 * Autor: Bruno
 */
public class Calculadora {
    private int num1;
    private int num2;

    // Construtor
    public Calculadora(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }

    // Método para somar
    public int some() {
        return num1 + num2;
    }

    // Método para subtrair
    public int subtraia() {
        return num1 - num2;
    }

    // Método para dividir, com tratamento de divisão por zero
    public int divida() {
        if (num2 != 0) {
            return num1 / num2;
        } else {
            throw new ArithmeticException("Divisão por zero não é permitida!");
        }
    }

    // Método para multiplicar
    public int multiplique() {
        return num1 * num2;
    }
}

