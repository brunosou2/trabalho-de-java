/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ccom.mycompany.mavenproject6;

import java.util.Random;

/**
 *
 * @author bruno
 */
// Classe Mago que herda Personagem
class Mago extends Personagem {

    // Construtor
    public Mago(String nome, int vida) {
        super(nome, vida);
    }

    // Implementação do ataque
    @Override
    public void atacar(Personagem p) {
        Random rand = new Random();
        int dano = rand.nextInt(10) + 2;
        System.out.println(this.getNome() + " jogou uma bola de fogo no " + p.getNome() + " causando " + dano + " de dano de fogo.");
        p.setVida(p.getVida() - dano);
    }
}
