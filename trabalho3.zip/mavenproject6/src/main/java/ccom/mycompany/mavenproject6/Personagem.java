/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ccom.mycompany.mavenproject6;

/**
 *
 * @author bruno
 */
import java.util.Random;


abstract class Personagem {
    private final String nome;
    private int vida;

    
    public Personagem(String nome, int vida) {
        this.nome = nome;
        this.vida = vida;
    }

    
    public abstract void atacar(Personagem p);

    
    public void curar() {
        Random rand = new Random();
        int cura = rand.nextInt(10) + 2; 
        this.vida += cura;
        System.out.println(this.nome + " cura " + cura + " de vida.");
    }

    
    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public boolean estaVivo() {
        return this.vida > 0;
    }
}

