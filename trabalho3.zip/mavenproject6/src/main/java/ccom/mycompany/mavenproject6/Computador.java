/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ccom.mycompany.mavenproject6;

import java.util.Random;

/**
 *
 * @author bruno
 */
// Classe Computador que implementa IA
class Computador implements IA {
    private final Personagem personagem;

    // Construtor
    public Computador(Personagem personagem) {
        this.personagem = personagem;
    }

    // Ação aleatória (atacar ou curar)
    @Override
    public void acaoAleatoria(Personagem alvo) {
        Random rand = new Random();
        if (rand.nextBoolean()) {
            personagem.atacar(alvo);
        } else {
            personagem.curar();
        }
    }
}

