/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ccom.mycompany.mavenproject6;

import java.util.Random;

/**
 *
 * @author bruno
 */

class Guerreiro extends Personagem {
    
    
    public Guerreiro(String nome, int vida) {
        super(nome, vida);
    }

   
    public void atacar(Personagem p) {
        Random rand = new Random();
        int dano = rand.nextInt(15)+2; 
        System.out.println(this.getNome() + " atacou " + p.getNome() + " causando " + dano + " de dano.");
        p.setVida(p.getVida() - dano);
    }
}

