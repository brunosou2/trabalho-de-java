package ccom.mycompany.mavenproject6;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Guerreiro jogador = new Guerreiro("Jogador", 100);
        Mago inimigo = new Mago("Inimigo", 100);
        Computador computador = new Computador(inimigo);

        try (Scanner scanner = new Scanner(System.in)) {
            while (jogador.estaVivo() && inimigo.estaVivo()) {
                System.out.println("Sua vida: " + Math.max(jogador.getVida(), 0)); // Evita exibir valores negativos
                System.out.println("Vida do inimigo: " + Math.max(inimigo.getVida(), 0)); // Evita exibir valores negativos
                System.out.println("Escolha sua ação: 1 - Atacar | 2 - Curar");

                // Verifica se a entrada é válida
                int escolha = 0;
                if (scanner.hasNextInt()) {
                    escolha = scanner.nextInt();
                } else {
                    System.out.println("Entrada inválida! Escolha um número.");
                    scanner.next(); // Limpa entrada inválida
                    continue; // Pula para a próxima iteração
                }

                // Ação do jogador
                switch (escolha) {
                    case 1 -> jogador.atacar(inimigo);
                    case 2 -> jogador.curar();
                    default -> {
                        System.out.println("Escolha inválida!");
                        continue;
                    }
                }

                // Verifica se o inimigo está vivo após ação do jogador
                if (inimigo.estaVivo()) {
                    System.out.println("O inimigo está agindo...");
                    computador.acaoAleatoria(jogador);
                } else {
                    System.out.println("Você venceu!");
                    break;
                }

                // Verifica se o jogador está vivo após ação do inimigo
                if (!jogador.estaVivo()) {
                    System.out.println("Você foi derrotado...");
                }
            }
        }
    }
}
